# Programming-Mobile-Applications-for-Android-Handheld-Systems--Part-2--University-of-Maryland
Contains hints and solutions of the quizzes and programming assignments of the course.
