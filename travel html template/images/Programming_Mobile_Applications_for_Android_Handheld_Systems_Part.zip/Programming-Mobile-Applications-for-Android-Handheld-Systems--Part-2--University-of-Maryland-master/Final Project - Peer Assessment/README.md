# Daily Selfie  
An android application that periodically reminds the user to take a selfie - a picture of one's self taken from one's device. Over time the user will capture many selfies and thus will be able to see him or herself change over some period of time.  

For application screencast refer [Daily Selfie Screen Cast](https://youtu.be/dLiQDQsSjqQ).