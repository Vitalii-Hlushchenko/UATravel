# Modern Art UI  
An android application displaying a UI with modern art as part of a course for developing android applications on Coursera.  

For application screencast refer [Modern Art UI Screen Cast](https://www.youtube.com/watch?v=Vpjl54ImAuE).